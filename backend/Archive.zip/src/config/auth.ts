export default {
    jwt: {
        secret: '006357f63369ab283bdd7cb538d36737',
        expiresIn: '1d',
    }
}